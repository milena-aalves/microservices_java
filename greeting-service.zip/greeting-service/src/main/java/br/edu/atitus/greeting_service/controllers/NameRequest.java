package br.edu.atitus.greeting_service.controllers;

public class NameRequest {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
