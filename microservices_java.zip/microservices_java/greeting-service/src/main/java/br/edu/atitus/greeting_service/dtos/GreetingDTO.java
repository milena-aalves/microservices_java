package br.edu.atitus.greeting_service.dtos;

public record GreetingDTO(String name) { 

}
